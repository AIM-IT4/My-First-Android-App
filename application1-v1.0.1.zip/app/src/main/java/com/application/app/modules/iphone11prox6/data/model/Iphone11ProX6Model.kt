package com.application.app.modules.iphone11prox6.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class Iphone11ProX6Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtVideoLectures: String? =
      MyApp.getInstance().resources.getString(R.string.msg_video_lectures)

)
