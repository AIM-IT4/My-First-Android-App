package com.application.app.modules.iphone11prox5.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class Iphone11ProX5Model(
  /**
   * TODO Replace with dynamic value
   */
  public var txtBooksWillBeS: String? =
      MyApp.getInstance().resources.getString(R.string.msg_books_will_be_s)

)
