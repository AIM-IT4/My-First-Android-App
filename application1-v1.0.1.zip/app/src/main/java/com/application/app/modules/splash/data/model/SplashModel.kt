package com.application.app.modules.splash.`data`.model

import com.application.app.R
import com.application.app.appcomponents.di.MyApp
import kotlin.String

public data class SplashModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txt910am: String? = MyApp.getInstance().resources.getString(R.string.lbl_9_10am)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtLearneriseApp: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_learnerise_app)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtFacingDifficul: String? =
      MyApp.getInstance().resources.getString(R.string.msg_facing_difficul)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtGetStarted: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_get_started)

)
